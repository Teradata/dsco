from IPython.core.magic import (
    Magics, magics_class, line_magic, cell_magic, line_cell_magic
)
import IPython.display as dis
import sqlalchemy
from sqlalchemy.exc import OperationalError
import pandas as pd
import numpy as np
import qgrid
import argparse
import configparser
import os
from jinja2 import Template

from pygments import highlight
from pygments.lexers import SqlLexer
from pygments.formatters import HtmlFormatter
import sqlparse


####################
# module variables #
####################

# Build arg parser
parser = argparse.ArgumentParser()
parser.add_argument(
    "-c", "--config",
    help="Name of config file"
)
parser.add_argument(
    "-f", "--format",
    help="set the response format for this cell"
)
parser.add_argument(
    "-i", "--ignore",
    help="Do not execute the sql in this cell",
    action="store_true"
)
parser.add_argument(
    "-l", "--long",
    help="Set pandas display option: max_rows"
)
parser.add_argument(
    "-q", "--query",
    help="Query text to run"
)
parser.add_argument(
    "-r", "--rows",
    help="Set max return rows"
)
parser.add_argument(
    "-s", "--save",
    help="Variable to save data frame"
)
parser.add_argument(
    "-t", "--template",
    help="Treat the cell as a jinja template. Render with given dictionary."
)
parser.add_argument(
    "-z", "--silent",
    help="Don't display output",
    action="store_true"
)
parser.add_argument(
    "-u", "--usage",
    action="store_true"
)
parser.add_argument(
    "-w", "--wide",
    help="Set pandas display option: max_columns"
)


def fsql(sql_, reindent=False):
    """Format text as an SQL statement"""
    return sqlparse.format(
        sql_,
        reindent=reindent,
        keyword_case='upper'
    )


def printsql(sql_string):
    """Prints an SQL statement with syntax highlighting"""
    style_string = """
    <style>
    {pygments_css}
    </style>
    """

    dis.display(
        dis.HTML(
            style_string.format(
                pygments_css=HtmlFormatter().get_style_defs('.highlight')
            )
        )
    )

    dis.display(
        dis.HTML(
            data=highlight(sql_string, SqlLexer(), HtmlFormatter())
        )
    )


def cols_df(df, sort_cols=False, ncol=3):
    """Takes in a dataframe and prints the columns as a dataframe"""
    cols = (sorted(df.columns.values.tolist()) if sort_cols
            else df.columns.values.tolist())
    npad = ncol - len(df.columns) % ncol
    cols = cols + [''] * npad
    return pd.DataFrame(np.array(cols).reshape((-1, ncol)))


#################
# Define Magics #
#################
@magics_class
class SqlMagic(Magics):
    """Custom magics for running sql on Teradata

    Connects to a Teradata system and executes sql commands
    """

    def __init__(self, shell):
        # call init from super class
        super(SqlMagic, self).__init__(shell)
        # define state variables
        # self.udaexec = None
        # self.session = None
        self.config_file = 'udaexec.ini'
        self.connections = dict()
        # some default values
        self.format = 'qgrid'
        self.row_limit = 2000
        self.qgrid_opts = {
            'forceFitColumns': False,
            'defaultColumnWidth': 150
        }

    def _query_system_info(self):
        username_col = 'UserName'
        system_col = 'ClientTdHostName'

        connection = self._get_connection()
        eng = connection['engine']
        sessionId: pd.DataFrame = pd.read_sql_query("select session;", eng)

        sessionId = sessionId.loc[0, "Session"]

        qry = 'select {}, {} from dbc.sessioninfo where SessionNo={};'.format(
            username_col, system_col, sessionId)

        df = pd.read_sql_query(qry, eng)

        u, s = df.loc[0, [username_col, system_col]]
        u = u if u else connection['username']
        s = s if s else connection['system']

        return s.lower().strip(), u.lower().strip()

    def _return_func_dict(self):
        """Create output function from current settings

        This is a function to allow options to be changed ad-hoc
        """
        return {
            'pandas': lambda df: df,
            'qgrid': lambda df: qgrid.show_grid(
                df,
                grid_options=self.qgrid_opts
            )
        }

    def _get_connection(self, reset=False):
        file_name = self.config_file
        config = configparser.ConfigParser()
        config.read(file_name)

        username = config['DEFAULT']['username']
        password = config['DEFAULT']['password']
        system = config['DEFAULT']['system']

        logmech = config['DEFAULT'].get('logmech', None)
        if logmech:
            logmech_string = "/?logmech={}".format(logmech)
        else:
            logmech_string = ''

        conn_string = "teradatasql://{u}:{p}@{s}{lm}".format(
            u=username, p=password, s=system, lm=logmech_string
        )

        connections = self.connections

        if not connections.get(conn_string) or reset:
            self.connections[conn_string] = {
                'engine': sqlalchemy.create_engine(conn_string),
                'username': username,
                'password': password,
                'system': system
            }

        return self.connections[conn_string]

    def _set_row_limit(self, num_rows):
        print("setting row limit to {}.".format(num_rows))
        self.row_limit = int(num_rows)

    def _run_query(self, args, sql):
        # set output function based on output format
        out_func_dict = self._return_func_dict()
        if args.format and args.format.lower() in out_func_dict.keys():
            out_func = out_func_dict[args.format.lower()]
        else:
            out_func = out_func_dict[self.format]

        # we can override this with an environment variable
        format_override = os.environ.get('FORMAT_OVERRIDE', None)
        if format_override and format_override.lower() in out_func_dict.keys():
            out_func = out_func_dict[format_override.lower()]

        # Get connection
        connection = self._get_connection()
        eng = connection['engine']

        # set row limit
        if args.rows:
            chunksize = int(args.rows)
            row_msg = "temporarily setting row limit to {}."
        else:
            chunksize = int(self.row_limit)
            row_msg = "limiting rows to {}."

        # execute the query
        try:
            # run query
            result_set = eng.execute(sql)
            assert isinstance(chunksize, int)
            df = pd.DataFrame(
                result_set.fetchmany(size=chunksize),
                columns=result_set.keys()
            )

            # Unless silent flag, print status
            if not args.silent:
                print("applying settings from {}.".format(self.config_file))
                print("querying {} as {}.".format(*self._query_system_info()))
                print(row_msg.format(chunksize))
                print("returning {} out of {} rows.".format(
                    df.shape[0], result_set.rowcount))

            # save results
            if args.save:
                self.shell.user_global_ns[args.save] = df

            # if the first column is 'Request Text', this is a show
            # table or view request so we output the DDL
            try:
                if df.columns[0] == 'Request Text':
                    printsql(df['Request Text'][0])
            except IndexError:
                # The dataframe was empty
                pass

            return out_func(df)

        except StopIteration:
            print("no rows returned.")

    @line_cell_magic
    def sql(self, line, cell=None):
        """cell magic function to designate cell as sql

        This cell magic interprets the cell as sql and submits it
        to the teradata system designated in the system variable.

        Args:
            line: contains any arguments on the same line as %%sql
                  These arguments can be used to modify default behavior.
                  see %%sql --help for a list of valid options.

        Returns:
            By default, displays results of query, but does not return anything.
            This can be modified with line options.
        """

        ##################
        # line arguments #
        ##################
        # look for command line arguments
        try:
            args = parser.parse_args(args=line.split())
        except SystemExit:
            return

        # if --ignore stop now
        if args.ignore:
            return

        if args.usage:
            print(self.sql.__doc__)
            return

        # if config is given replace default
        if args.config:
            if os.path.isfile(args.config):
                self.config_file = args.config
            else:
                print("CONFIG FILE NOT FOUND: {}.".format(args.config))
                return

        if args.query:
            try:
                cell = self.shell.user_global_ns[args.query]
            except KeyError:
                print("{} not found.".format(args.query))
                return

        if args.template:
            try:
                parameters = self.shell.user_global_ns[args.template]
                template = Template(cell)
                cell = template.render(parameters)
                if not args.silent:
                    printsql(fsql(cell))

            except KeyError:
                print("{} not found.".format(args.template))
                return

        #################
        # Run the query #
        #################
        separated_queries = [i.strip() for i in cell.split(';')]
        out = []  # Output()
        for sql in [i for i in separated_queries if i]:
            # with out:
            # connection can be lost, try to reconnect
            retries = 2
            exception_found = None
            for i in range(retries):
                try:
                    df = self._run_query(args, sql)

                except TypeError:
                    return "no results"

                except OperationalError as e:
                        print("{}, attempting to reconnect.".format(type(e)))
                        self._get_connection(reset=True)
                        exception_found = e

                else:
                    if not args.silent:
                        if isinstance(df, pd.core.frame.DataFrame):
                            max_rows = args.long if args.long else df.shape[0]
                            max_cols = args.wide if args.wide else df.shape[1]
                            with pd.option_context(
                                        'display.max_rows', int(max_rows),
                                        'display.max_columns', int(max_cols)):
                                dis.display(df)
                        else:
                            dis.display(df)
                    out.append(df)
                    exception_found = None
                    break

            if exception_found: raise exception_found

        # not returning anything, use the save option
        # if False:
        #     return out


    ############################
    # Cell magic to format sql #
    ############################
    @cell_magic
    def fsql(self, line, cell):
        """Format cell contents as SQL"""
        raw_code = fsql(cell, reindent=True)
        self.shell.set_next_input('%%sql --ignore\n{}'.format(raw_code), replace=True)

    ###################################################
    # Line Magics to modify default behavior of %%sql #
    ###################################################
    @line_magic
    def set_output_format(self, line):
        """Set the output format for the current session"""
        frmt = line.lower()
        known_formats = self._return_func_dict().keys()
        if frmt in known_formats:
            self.format = frmt
            print("output format set to {}.".format(frmt))
        else:
            print("{} not a known format.".format(frmt))

    @line_magic
    def set_config_file(self, line):
        """Set the config file for the current session"""
        if os.path.isfile(line):
            self.config_file = line
        else:
            print("CONFIG FILE NOT FOUND: {}.".format(line))
            return

    @line_magic
    def get_current_grid_options(self, line):
        """Get the current qgrid options"""
        return self.qgrid_opts

    @line_magic
    def set_qgrid_options(self, line):
        """Update the current qgrid options"""
        # line should contain the name of the variable
        #     defining the new grid options
        try:
            _qgrid_opts = self.shell.user_global_ns[line]
            self.qgrid_opts = _qgrid_opts

        except KeyError:
            print("{} not found. Options unchanged.".format(line))
    
    @line_magic
    def set_row_limit(self, line):
        """Modify the default row limit"""
        self._set_row_limit(line)
