from tdsqlmagic.deploy import example_notebook


def main():
    example_notebook()


if __name__ == '__main__':
    main()
