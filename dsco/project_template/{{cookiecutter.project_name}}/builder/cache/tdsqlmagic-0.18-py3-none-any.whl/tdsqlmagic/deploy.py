import os
from shutil import copy2


def example_notebook():
    current_loc = os.path.dirname(os.path.realpath(__file__))
    notebook_relative_path = os.path.join('templates', 'default.ipynb')
    src = os.path.join(current_loc, notebook_relative_path)
    dst = os.getcwd()
    copy2(src, dst)
