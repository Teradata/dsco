"""TdSqlMagic is a tool for running sql in code cells"""

from IPython import get_ipython
from .sqlmagic import SqlMagic


def load_ipython_extension(ipython):
    ipython.register_magics(SqlMagic)


ip = get_ipython()

load_ipython_extension(ip)
